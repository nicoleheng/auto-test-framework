# ExtentX Community 1.0.2

Report Server for ExtentReports

### Supported ExtentReports Versions

* ExtentReports Java Pro 3.0.0+
* ExtentReports Java Community 3.0.1+
* ExtentReports .NET Community 3.0.0+

### Download

Download from [extentreports.com](http://extentreports.com/community/)
