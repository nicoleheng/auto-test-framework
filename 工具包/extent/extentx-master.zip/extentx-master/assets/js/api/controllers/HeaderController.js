angular.module('ExtentX').
    controller('HeaderController', ['$rootScope', '$scope', function($rootScope, $scope) {
        $rootScope.viewName = "Analysis";
    }]);